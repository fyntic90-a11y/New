import re, pathlib
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
t = m.read_text()
home = """
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.HOME" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
"""
t = t.replace("</activity>", home + "        </activity>", 1)
t = t.replace('android:launchMode="singleTask"', 'android:launchMode="singleTask" android:screenOrientation="portrait" android:excludeFromRecents="false"', 1)
m.write_text(t)
s = pathlib.Path("android/app/src/main/res/values/styles.xml")
x = s.read_text().replace("</style>", '<item name="android:windowFullscreen">true</item><item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item></style>')
s.write_text(x)
print("patched")
